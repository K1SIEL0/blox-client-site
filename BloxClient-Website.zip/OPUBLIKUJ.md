# Darmowa publikacja strony Blox Client

Strona jest statyczna i może być hostowana bezpłatnie przez GitHub Pages.

1. Załóż bezpłatne konto na GitHubie, jeśli jeszcze go nie masz.
2. Utwórz **publiczne** repozytorium o nazwie `blox-client-site`.
3. Wgraj do jego katalogu głównego wszystkie pliki z tego folderu: `index.html`, `assets/`, `.nojekyll` i `.github/`.
4. W repozytorium otwórz **Settings → Pages** i jako źródło wybierz **GitHub Actions**.
5. Po pierwszym udanym uruchomieniu workflow strona będzie dostępna pod adresem `https://TWÓJ-LOGIN.github.io/blox-client-site/`.

To osobny zestaw plików strony — nie musisz publikować kodu launchera. Repozytorium musi być publiczne, aby korzystać z GitHub Pages w bezpłatnym planie. Oficjalny opis wdrożenia przez GitHub Actions: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

Sekcja pobierania na stronie pozostaje oznaczona jako „wkrótce”, dopóki nie zostanie dodany oficjalny link do wydania launchera.
